create definer = root@localhost view v_res_cli_hot as
select `hotel`.`reservation`.`res_id` AS `num resa`,
       `hotel`.`client`.`cli_nom`     AS `nom client`,
       `hotel`.`hotel`.`hot_nom`      AS `nom hot`
from (((`hotel`.`reservation` join `hotel`.`client` on (`hotel`.`client`.`cli_id` = `hotel`.`reservation`.`res_cli_id`)) join `hotel`.`chambre` on (`hotel`.`reservation`.`res_cha_id` = `hotel`.`chambre`.`cha_id`))
         join `hotel`.`hotel` on (`hotel`.`chambre`.`cha_hot_id` = `hotel`.`hotel`.`hot_id`));

