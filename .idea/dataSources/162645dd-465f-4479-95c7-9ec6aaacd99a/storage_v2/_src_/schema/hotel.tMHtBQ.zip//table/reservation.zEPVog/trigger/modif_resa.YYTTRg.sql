create definer = root@localhost trigger modif_resa
    before update
    on reservation
    for each row
BEGIN

SIGNAL SQLSTATE '40000' SET MESSAGE_TEXT = 'impossible de modifier les reservations ';

END;

